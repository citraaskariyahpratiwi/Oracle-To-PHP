<?php
//membangun koneksi
$username ="system";
$password ="123";
$database ="LOCALHOST/XE";
$koneksi=oci_connect ($username,$password,$database);
if(!$koneksi) {
$err=oci_error();
echo "Gagal tersambung ke ORACLE", $err['text'];
} else {
echo "Koneksi Berhasil";
}
?>