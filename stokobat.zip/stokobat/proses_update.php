<?php
require_once 'koneksi.php';
if (isset($_POST['submit'])) {
  $kode = $_POST['kode_obat'];
  $nama = $_POST['nama_obat'];
  $stok = $_POST['stok'];
  $satuan = $_POST['satuan'];
  $harga = $_POST['harga_pokok'];
 
  
  // update data berdasarkan id_produk yg dikirimkan
  
	$query = "UPDATE  STOK_OBAT  SET NAMA_OBAT ='".$nama."', STOK ='".$stok."', SATUAN ='".$satuan."', HARGA_POKOK ='".$harga."' WHERE KODE_OBAT = '".$kode."' ";
	$statement = oci_parse($koneksi,$query);
	$r = oci_execute($statement,OCI_DEFAULT);
	 $res = oci_commit($koneksi);
  if ($res) {
    // pesan jika data berubah
    echo "<script>alert('Data Stok Obat berhasil diubah'); window.location.href='stokobat.php'</script>";
  } else {
    // pesan jika data gagal diubah
    echo "<script>alert('Data Stok Obat gagal diubah'); window.location.href='stokobat.php'</script>";
  }
} else {
  // jika coba akses langsung halaman ini akan diredirect ke halaman index
  header('Location: stokobat.php'); 
}