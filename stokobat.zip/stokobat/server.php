<?php
$koneksi = oci_connect("system","123","LOCALHOST/XE");
/*
 di tulis oleh : CITRA ASKARIYAH PRATIWI
 */
$kursor = ocicommit($koneksi);
?>