<?php
require_once 'koneksi.php';
if (isset($_POST['submit'])) {
  $kode = $_POST['kode_obat'];
  $nama = $_POST['nama_obat'];
  $stok = $_POST['stok'];
  $satuan = $_POST['satuan'];
  $harga = $_POST['harga_pokok'];

	$query = "INSERT INTO stok_obat (KODE_OBAT,NAMA_OBAT,STOK,SATUAN,HARGA_POKOK) VALUES ('".$kode."','".$nama."','".$stok."','".$satuan."','".$harga."')";
	$statement = oci_parse($koneksi,$query);
	$r = oci_execute($statement,OCI_DEFAULT);
	 $res = oci_commit($koneksi);
  if ($res) {
    // pesan jika data tersimpan
    echo "<script>alert('Data Stok Obat berhasil ditambahkan'); 
	window.location.href='stokobat.php'</script>";
  } else {
    // pesan jika data gagal disimpan
    echo "<script>alert('Data Stok Obat gagal ditambahkan');
	window.location.href='stokobat.php'</script>";
  }
} else {
  //jika coba akses langsung halaman ini akan diredirect ke halaman index
  header('Location: stokobat.php'); 
}