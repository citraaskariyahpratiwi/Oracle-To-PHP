<?php
//ganti dengan username dan password anda 
$koneksi = oci_connect("system", "123", "localhost/XE");
 ?>
